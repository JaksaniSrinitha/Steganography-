
from cryptography.fernet import Fernet
from PIL import Image

# Generate a key for encryption
def generate_key():
    return Fernet.generate_key()

# Encrypt the message using AES (Fernet for simplicity)
def encrypt_message(key, message):
    fernet = Fernet(key)
    return fernet.encrypt(message.encode())

# Decrypt the message
def decrypt_message(key, encrypted_message):
    fernet = Fernet(key)
    return fernet.decrypt(encrypted_message).decode()

# Embed binary message in image using LSB
def embed_message(image_path, message, output_path):
    img = Image.open(image_path)
    binary_message = ''.join(format(byte, '08b') for byte in message)
    binary_message += '1111111111111110'  # Delimiter to indicate end of message

    pixels = list(img.getdata())
    new_pixels = []
    message_index = 0

    for pixel in pixels:
        new_pixel = list(pixel)
        for i in range(3):  # RGB
            if message_index < len(binary_message):
                new_pixel[i] = new_pixel[i] & ~1 | int(binary_message[message_index])
                message_index += 1
        new_pixels.append(tuple(new_pixel))

    img.putdata(new_pixels)
    img.save(output_path)

# Extract binary message from image
def extract_message(image_path):
    img = Image.open(image_path)
    pixels = list(img.getdata())
    binary_data = ""

    for pixel in pixels:
        for i in range(3):
            binary_data += str(pixel[i] & 1)

    # Split binary data into bytes until delimiter is found
    all_bytes = [binary_data[i:i+8] for i in range(0, len(binary_data), 8)]
    message_bytes = bytearray()
    for byte in all_bytes:
        if byte == '11111110':  # End delimiter
            break
        message_bytes.append(int(byte, 2))
    return bytes(message_bytes)

# Example usage
if __name__ == "__main__":
    key = generate_key()
    print(f"Encryption Key: {key.decode()}")
    message = "Hello, this is a secret message!"
    encrypted = encrypt_message(key, message)
    embed_message("input.png", encrypted, "stego_output.png")
    extracted = extract_message("stego_output.png")
    decrypted = decrypt_message(key, extracted)
    print(f"Decrypted Message: {decrypted}")
