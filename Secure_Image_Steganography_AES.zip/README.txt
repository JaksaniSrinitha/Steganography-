
# Secure Image Steganography using AES Encryption

## Requirements
- Python 3.x
- cryptography
- Pillow

## How to Run
1. Install dependencies:
   pip install cryptography Pillow

2. Place an image named 'input.png' in the project folder.

3. Run the main.py:
   python main.py

## Output
- Encrypted message will be embedded into `stego_output.png`
- Decrypted message will be printed on terminal

## Note
- AES encryption is done using Fernet (built on AES)
